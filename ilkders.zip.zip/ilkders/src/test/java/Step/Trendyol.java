package Step;

import Driver.Chrome;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class Trendyol {
    protected WebDriver ders= Chrome.getDriver();
    @Given("Trendyola get")
    public void Trendyola_get (){
        ders.get("https://google.com");
    }

    @When("")

}
