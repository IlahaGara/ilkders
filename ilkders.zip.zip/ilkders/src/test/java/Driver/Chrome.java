package Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Chrome {
    public static WebDriver getDriver ()  {
        WebDriver ders;
        System.setProperty("webderiver.chrome.driver", "src/test/resources/Driver/chromedriver.exe");
        ders =new ChromeDriver();
        ders.manage().window().maximize();
        return ders;

    }
}
